package src_class.src_class_commande;

public class CommandeRemove {
    
}
