source script_destruction_BDD_table.sql;
source script_creation_BDD_table.sql;
source script_insert.sql;