insert into CLIENT (username, ip, isAdmin) values
    ("serveur", "localhost", 1);